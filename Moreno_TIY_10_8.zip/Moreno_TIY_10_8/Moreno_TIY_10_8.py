from pathlib import Path

####################################

#pCat = Path("cats.txt")
#pDog = Path("dogs.txt")

#c = "Nala\n"
#c += "Glizzy\n"
#c += "Pumpkin\n"

#d = "Pancha\n"
#d += "Mickey\n"
#d += "Luna\n"

#pCat.write_text(c)
#pDog.write_text(d)

##### CODE TO MAKE TXT FILES #########

try:
    pCat = Path("cats.txt")
    cat_content = pCat.read_text(encoding="utf-8")

    print(f"\n")

    for l in cat_content.splitlines():
        print(l)

    print(f"\n")

except FileNotFoundError:
    #print(f"\nThe file '{pCat} does not exist.\n")
    pass


try:
    pDog = Path("dogs.txt")
    dog_content = pDog.read_text(encoding="utf-8")

    print(f"\n")

    for l in dog_content.splitlines():
        print(l)

    print(f"\n")

except FileNotFoundError:
    #print(f"\nThe file '{pDog} does not exist.\n")
    pass