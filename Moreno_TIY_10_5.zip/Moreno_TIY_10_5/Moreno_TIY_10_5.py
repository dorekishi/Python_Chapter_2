from pathlib import Path

p = Path('guest_book.txt')

l = []

print(f"\nType 'q' To Quit.")

while True:

    w = ''

    r = input('\nEnter Your Name: ')

    if r == 'q':
        break

    l.append(r)

    for n in l:
        w += f"{n}\n"
        p.write_text(w)

    print(f"Thank You {r}.\nYour Name Has Been Added To The Guest Book.")