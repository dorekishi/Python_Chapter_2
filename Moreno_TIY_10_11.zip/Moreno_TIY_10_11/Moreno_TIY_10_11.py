from pathlib import Path
import json

fav_num = input(f"What is your favorite number? ")

p = Path(f"favorite_number.json")
contents = json.dumps(fav_num)
p.write_text(contents)