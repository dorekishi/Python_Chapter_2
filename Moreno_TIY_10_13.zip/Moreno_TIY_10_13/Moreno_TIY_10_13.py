from pathlib import Path
import json

name = input("\nWhat is your name? ")
birthday = input("\nWhen is your birthday? ")
address  = input("\nWhat is your address? ")

user = {
    "name":       name,
    "birthday":   birthday,
    "address":    address,
}

path = Path("10_13.json")

contents = json.dumps(user)
path.write_text(contents)

print(f"\nInformation gathered will be read back.")

contents_regurgitated = path.read_text()

user_dictionary_regurgitated = json.loads(contents_regurgitated)

print(f"\nName Provided:      {user_dictionary_regurgitated['name']}\n"
      f"Birthday Provided:  {user_dictionary_regurgitated['birthday']}\n"
      f"Address Provided:   {user_dictionary_regurgitated['address']}\n")