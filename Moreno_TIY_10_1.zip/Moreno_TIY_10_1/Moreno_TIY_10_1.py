from pathlib import Path

lp = Path('learning_python.txt')
lp_contents = lp.read_text()

print(f"\n{lp_contents}\n")

for line in lp_contents.splitlines():
    print(line)