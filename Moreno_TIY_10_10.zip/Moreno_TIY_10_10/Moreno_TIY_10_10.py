from pathlib import Path

p = Path(f"murder_by_the_clock.txt")
c = p.read_text(encoding=f"utf-8")

print(c.lower().count('the'))
# 'the' appears 3845 times in the novel, 'murder by the clock',
# but that includes words like there, them, etc.

print(c.lower().count('the '))
# 'the ' appears 2462 times in the novel, but that includes
# words that have 'the' and the end of their body
# difference of 1383 from previous attempt

print(c.lower().count(' the '))
# finally, 'the', shows up 2213 times by itself
# difference of 249 from previous attempt