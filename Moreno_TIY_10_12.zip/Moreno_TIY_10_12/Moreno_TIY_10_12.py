from pathlib import Path
import json

p = Path(f"favorite_number.json")

try:
    contents = p.read_text()
    favorite_number = json.loads(contents)
    print(f"I know your favorite number! It's {favorite_number}.")
except:
    fav_num = input(f"What is your favorite number? ")
    contents = json.dumps(fav_num)
    p.write_text(contents)