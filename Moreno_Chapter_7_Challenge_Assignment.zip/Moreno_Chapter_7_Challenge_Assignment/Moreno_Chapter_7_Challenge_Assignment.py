import csv

# Pull in the CSV file
filename = 'Chapter_7 Challenge - Form Responses 1.csv'
with open(filename) as f:
    reader = csv.reader(f)
    header_row = next(reader)
    # Loop through the csv file and create two lists
    names = []
    candy_types_1 = []
    candy_types_2 = []
    candy_prices_1 = []
    candy_prices_2 = []

    for row in reader:
        each_name = row[1]
        candy_1 = row[2]
        candy_2 = row[4]
        price_1 = float(row[3])
        price_2 = float(row[5])

        # add the code here that will append each variable above into the correct list.
        names.append(each_name)
        candy_types_1.append(candy_1)
        candy_types_2.append(candy_2)
        candy_prices_1.append(price_1)
        candy_prices_2.append(price_2)
    # Print each list
#    print(names)
 #   print(candy_types_1)
  #  print(candy_types_2)
   # print(candy_prices_1)
    #print(candy_prices_2)

    # Start assignment

    # Identify duplicates and remove them since they mess up dictionaries keys, can't have same name
    # set() - identifies unique items in collection and builds a set from those items
                                                                                                                       #
    # 24 Created



candy_check_1 = candy_types_1[:]


for candy_type in set(candy_check_1):
    if candy_type in candy_check_1:
        candy_check_1.remove(candy_type)

    # print(candy_check_1)    # I got rows 6, 12, 21, 22, 23, 30
    # Numbers above are one back from the ACTUAL row in the spreadsheet since row 1 contains titles
candy_types_1[29] = 'Please Select a New Candy (0)'  # Remove going backwards since .remove() will upset order of list
candy_types_1[22] = 'Please Select a New Candy (1)'  # Also have to go back one number since it counts from 0, up
candy_types_1[21] = 'Please Select a New Candy (2)'
candy_types_1[20] = 'Please Select a New Candy (3)'
candy_types_1[11] = 'Please Select a New Candy (4)'
candy_types_1[5] = 'Please Select a New Candy (5)'

    # Since the prices should be in the same spots as well, I can remove them too with the same numbers

candy_prices_1[29] = ''  # Remove going backwards since .remove() will upset order of list
candy_prices_1[22] = ''  # Also have to go back one number since it counts from 0, up
candy_prices_1[21] = ''
candy_prices_1[20] = ''
candy_prices_1[11] = ''
candy_prices_1[5] = ''
    # Old thing and new thing used to solve this

                                                                                                                       #
    # 28 Created

candy_check_2 = candy_types_2[:]


for candy_type in set(candy_check_2):
    if candy_type in candy_check_2:
        candy_check_2.remove(candy_type)

    # print(candy_check_2)    # I got rows 19, 30
    # Numbers above are one back from the ACTUAL row in the spreadsheet (csv file) since row 1 contains titles
candy_types_2[29] = 'Please Select a New Candy (6)'  # Remove going backwards since .remove() will upset order of list
candy_types_2[18] = 'Please Select a New Candy (7)'  # Also have to go back one number since it counts from 0, up


    # Since the prices should be in the same spots as well, I can remove them too with the same numbers

candy_prices_2[29] = ''  # Remove going backwards since .remove() will upset order of list
candy_prices_2[18] = ''  # Also have to go back one number since it counts from 0, up

                                                                                                                       #


candy_check_3 = []
    # Add ALL candies to a list since it can hold multiple similar elements unlike a dictionary
for candy_type in candy_types_1:
    candy_check_3.append(candy_type)
for candy_type in candy_types_2:
    candy_check_3.append(candy_type)

    # print(candy_check_3)

    # Identify duplicates
for candy_type in set(candy_check_3):
    if candy_type in candy_check_3:
        candy_check_3.remove(candy_type)





candy_check_4 = []

for candy_type in candy_types_1:
    candy_check_4.append(candy_type)
for candy_type in candy_types_2:
    candy_check_4.append(candy_type)

    # print(candy_check_3)

    # Identify duplicates
for candy_type in set(candy_check_4):
    if candy_type in candy_check_4:
        candy_check_4.remove(candy_type)

    # print(candy_check_4) absolutely NO duplicates :)


########################################################################################################################
    # print('\n\n\n')
    # print(candy_check_3)    # FOR COLUMN F (column 6) (candy_types_2), remove 12, 13, 17
    # Numbers above are one back from EXACT spot in spreadsheet (csv file)
candy_types_2[16] = 'Please Select a New Candy (8)' # Go back one number since it counts from zero
candy_types_2[12] = 'Please Select a New Candy (9)' # Go backwards since order of list will be reordered
candy_types_2[11] = 'Please Select a New Candy (10)'

candy_prices_2[16] = '' # Go back one number since it counts from zero
candy_prices_2[12] = '' # Go backwards since order of list will be reordered
candy_prices_2[11] = ''
########################################################################################################################

survey_entries = {}

for name, candy_type_1, candy_price_1, candy_type_2, candy_price_2 in zip(names, candy_types_1, candy_prices_1,
                                                                          candy_types_2, candy_prices_2):
    survey_entries[name] = {candy_type_1 : candy_price_1, candy_type_2 : candy_price_2}
    # EX: 'Damien': {'Almond Joy': 1.96, "Reece's": 2.06}

                                                                                                                       #
    # Create a loop that in order allows a user to
    # Type their name to see their 'order'
    # OR end program by typing 'exit'
    # Have choice to change 'order'
    # INCLUDE note that their order may have not been accepted due to process errors
    # If yes then give user 'receipt' of change
    # If not then restart the loop



active = True

while active:

    print("(Type 'exit' To Quit The Program.)")
    name = input('Hello, Please Enter Your Name to Find Your Order: ')

    if name == 'exit':
        break

    if name not in survey_entries:
        print('Please Try Again.')
        print('\n')
        continue

    print(f"Order:")

    #
    #Order:
    #   input_name
    #       1: candy
    #       2: candy
    #

    print(f"\t\t{survey_entries[name]}")

    print('\n')

    response = input(f"Would You Like to Change Order? (yes/no) ")

    print('\n')

    if response == 'yes':

        response = input('Would You Like to Change Candies ? (yes/no) ')

        print('\n')

        if response == 'yes':

            try:

                change_candy_1 = input('First Candy: ')

            except ValueError:
                print('Please Try Again.')
                print('\n')
                continue

            try:

                change_price_1 = input("First Candy's Price: ")

                change_price_1 = int(change_price_1)

            except ValueError:
                print('Please Try Again.')
                print('\n')
                continue

            try:

                change_candy_2 = input('Second Candy: ')

            except ValueError:
                print('Please Try Again.')
                print('\n')
                continue

            try:

                change_price_2 = input("Second Candy's Price: ")

                change_price_2 = int(change_price_2)

            except ValueError:
                print('Please Try Again.')
                print('\n')
                continue

            del survey_entries[name]

            survey_entries[name] = {change_candy_1: change_price_1, change_candy_2: change_price_2}

            print('\n')

            print('Changes Made:')

            print(survey_entries[name])

        else:
            continue

    print('\n')