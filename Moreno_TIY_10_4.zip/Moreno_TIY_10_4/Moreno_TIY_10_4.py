from pathlib import Path

p = Path('guest.txt')

r = input('Enter Your Name: ')

print(f"Thank You {r}.")

p.write_text(r)