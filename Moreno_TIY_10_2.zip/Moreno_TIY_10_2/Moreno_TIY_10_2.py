from pathlib import Path
lp = Path('learning_python.txt')
lp_contents = lp.read_text()

lc_contents = ''

for line in lp_contents.splitlines():
    lc_contents += line.replace('Python', 'C')
    lc_contents += '\n'

print(lc_contents)